const express = require('express')
const bodyParser = require('body-parser');
const mustacheExpress = require('mustache-express');
const products = require('./products.js');

const app = express()

app.use(bodyParser.json());
app.use(express.static('public'));
app.engine('html', mustacheExpress());
app.set('view engine', 'html');
app.set('views', __dirname + '/public/views');

app.get('/', (req,res) => {
    res.render('index')
})

app.get('/health', (req,res) => {
    res.send('OK');
})

app.get("/products", async (req,res) => {
    var productList = await products.get();
    res.send(productList);
})

app.get('/products/:id', async (req, res) => {
    const id = req.params.id;
    var product = await products.getById(id);
    res.send(product);
})

app.listen(3000, () => { 
    console.log('Web listening on port 3000!') 
})