exports.get = async function(){
    var productList = [
        { id:1, name: "Apples"},
        { id:2, name: "Pears"},
        { id:3, name: "Nuts"},
        { id:4, name: "Milk"},
        { id:5, name: "Honey"},
        { id:6, name: "Chicken"},
    ]
    return productList;
}

exports.getById = async function(id){
    return { id:1, name: "Apples"};
}