import os

print('I found the following values in FOO and ZIP:')
print(os.environ['FOO'])
print(os.environ['ZIP'])
