# Instructions

1. Open a termianl and navigate to this folder
2. Modify the file `producer/producer.properties` according to your needs
3. Build the Docker image for the producer: 

    `docker image build gnschenker/cc-auth-producer:gke producer`

4. Push the image to image to Google hub